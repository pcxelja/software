// I18N constants
// LANG: "nl", ENCODING: UTF-8
// translated: Arthur Bogaart a.bogaart@onehippo.org
{
  "Maximize/Minimize Editor": "Editor maximaliseren/verkleinen"
};
